/**
 * project.js — Project Life-Cycle Hub
 * Manages the project detail view:
 *   - Displays lifecycle stages with tasks
 *   - Add tasks per stage
 *   - Mark tasks complete (updates progress bar in real time)
 *   - Delete tasks
 *   - Collapsible stage panels
 */

const API = '/api';

// Project ID from URL query string: project.html?id=1
const PROJECT_ID = new URLSearchParams(window.location.search).get('id');

// ─── Initialization ──────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  if (!PROJECT_ID) {
    document.getElementById('projectHeader').innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🔍</div>
        <h3>No project selected</h3>
        <p>Return to the dashboard and click a project.</p>
        <a href="index.html" class="btn btn-primary">Go to Dashboard</a>
      </div>`;
    return;
  }
  loadProject();
});

// ─── State ───────────────────────────────────────────────────────────────────

// Holds the current project data so we can update progress without re-fetching
let currentProject = null;

// ─── API Calls ───────────────────────────────────────────────────────────────

async function loadProject() {
  try {
    const project = await apiFetch(`${API}/projects/${PROJECT_ID}`);
    currentProject = project;
    document.title = `${project.name} — Life-Cycle Hub`;
    renderProjectHeader(project);
    renderStages(project);
  } catch (err) {
    document.getElementById('projectHeader').innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">⚠️</div>
        <h3>Could not load project</h3>
        <p>${err.message}</p>
        <a href="index.html" class="btn btn-primary">Go to Dashboard</a>
      </div>`;
  }
}

async function createTask(stageId, title) {
  return apiFetch(`${API}/tasks`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, stageId, projectId: Number(PROJECT_ID) }),
  });
}

async function completeTask(taskId) {
  return apiFetch(`${API}/tasks/${taskId}/complete`, { method: 'PATCH' });
}

async function deleteTaskById(taskId) {
  return apiFetch(`${API}/tasks/${taskId}`, { method: 'DELETE' });
}

// ─── Rendering ───────────────────────────────────────────────────────────────

function renderProjectHeader(project) {
  const headerEl = document.getElementById('projectHeader');
  const progress  = project.progress ?? 0;
  const fillClass = progress >= 100 ? 'complete' : '';

  const desc = project.description
    ? `<p class="project-detail-description">${escapeHtml(project.description)}</p>`
    : '';

  headerEl.innerHTML = `
    <div class="project-detail-header">
      <h1 class="project-detail-title">${escapeHtml(project.name)}</h1>
      <div class="project-detail-meta">
        <span class="stage-badge stage-${project.currentStage}">${project.currentStage}</span>
        <span class="text-muted" style="font-size:0.85rem;">
          ${project.completedTasks}/${project.totalTasks} tasks completed
        </span>
      </div>
      ${desc}
    </div>

    <div class="progress-hero">
      <div class="progress-hero-label">
        <span>Overall Progress</span>
        <strong id="progressPercent">${progress}%</strong>
      </div>
      <div class="progress-hero-bar">
        <div class="progress-hero-fill ${fillClass}" id="progressFill" style="width:${progress}%"></div>
      </div>
    </div>`;
}

function renderStages(project) {
  const container = document.getElementById('stagesContainer');

  if (!project.stages || project.stages.length === 0) {
    container.innerHTML = '<p class="text-muted">No stages found.</p>';
    return;
  }

  container.innerHTML = `
    <div class="stages-container" id="stagesList">
      ${project.stages.map((stage, idx) => renderStagePanel(stage, idx, project.currentStage)).join('')}
    </div>`;

  // Bind collapse toggles
  document.querySelectorAll('.stage-panel-header').forEach(header => {
    header.addEventListener('click', (e) => {
      // Don't collapse if clicking inside the header's right-side button area
      if (e.target.closest('button')) return;
      const panel = header.closest('.stage-panel');
      panel.classList.toggle('collapsed');
    });
  });
}

function renderStagePanel(stage, idx, currentStage) {
  const isActive    = stage.name === currentStage;
  const activeClass = isActive ? 'active-stage' : '';
  const taskCount   = stage.tasks ? stage.tasks.length : 0;
  const doneCount   = stage.tasks ? stage.tasks.filter(t => t.completed).length : 0;

  return `
    <div class="stage-panel ${activeClass}" data-stage-id="${stage.id}" id="stage-${stage.id}">
      <div class="stage-panel-header">
        <div class="stage-panel-left">
          <div class="stage-number">${idx + 1}</div>
          <span class="stage-badge stage-${stage.name} stage-panel-name">${stage.name}</span>
        </div>
        <div class="stage-panel-right">
          <span class="stage-task-count">${doneCount}/${taskCount} done</span>
          <span class="stage-collapse-icon">▾</span>
        </div>
      </div>

      <div class="stage-panel-body">
        <div class="task-list" id="tasks-${stage.id}">
          ${renderTaskItems(stage.tasks)}
        </div>

        <!-- Add Task Form -->
        <div class="add-task-form" id="addForm-${stage.id}">
          <input
            type="text"
            class="add-task-input"
            id="addInput-${stage.id}"
            placeholder="Describe the task…"
            maxlength="500"
          />
          <div class="add-task-actions">
            <button class="add-task-save" onclick="submitAddTask(${stage.id})">Add</button>
            <button class="add-task-cancel" onclick="hideAddTaskForm(${stage.id})">✕</button>
          </div>
        </div>

        <button class="add-task-trigger" id="addTrigger-${stage.id}" onclick="showAddTaskForm(${stage.id})">
          + Add task
        </button>
      </div>
    </div>`;
}

function renderTaskItems(tasks) {
  if (!tasks || tasks.length === 0) {
    return '<div class="no-tasks">No tasks yet — add one below</div>';
  }

  return tasks.map(task => `
    <div class="task-item ${task.completed ? 'completed' : ''}" id="task-${task.id}" data-task-id="${task.id}">
      <div
        class="task-checkbox"
        title="${task.completed ? 'Already completed' : 'Mark as done'}"
        onclick="${task.completed ? '' : `handleCompleteTask(${task.id})`}"
        style="cursor: ${task.completed ? 'default' : 'pointer'}"
      >${task.completed ? '✓' : ''}</div>
      <span class="task-title">${escapeHtml(task.title)}</span>
      <button
        class="task-delete-btn"
        title="Delete task"
        onclick="handleDeleteTask(${task.id})"
        aria-label="Delete task"
      >✕</button>
    </div>`).join('');
}

// ─── Task Actions ─────────────────────────────────────────────────────────────

async function handleCompleteTask(taskId) {
  const taskEl = document.getElementById(`task-${taskId}`);
  if (!taskEl) return;

  // Optimistic UI — mark visually immediately
  taskEl.classList.add('completed');
  const checkbox = taskEl.querySelector('.task-checkbox');
  if (checkbox) {
    checkbox.textContent = '✓';
    checkbox.style.background = 'var(--success)';
    checkbox.style.borderColor = 'var(--success)';
    checkbox.onclick = null;
    checkbox.style.cursor = 'default';
  }

  try {
    await completeTask(taskId);
    // Reload project to get fresh progress without full page reload
    await refreshProgress();
    showToast('Task completed ✓', 'success');
  } catch (err) {
    // Roll back optimistic UI
    taskEl.classList.remove('completed');
    if (checkbox) {
      checkbox.textContent = '';
      checkbox.style.background = '';
      checkbox.style.borderColor = '';
      checkbox.onclick = () => handleCompleteTask(taskId);
      checkbox.style.cursor = 'pointer';
    }
    showToast(err.message, 'error');
  }
}

async function handleDeleteTask(taskId) {
  if (!confirm('Delete this task?')) return;

  try {
    await deleteTaskById(taskId);
    const taskEl = document.getElementById(`task-${taskId}`);
    if (taskEl) {
      taskEl.style.opacity = '0';
      taskEl.style.height = '0';
      taskEl.style.overflow = 'hidden';
      taskEl.style.transition = 'all 0.2s';
      setTimeout(() => taskEl.remove(), 250);
    }
    await refreshProgress();
    showToast('Task deleted', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// ─── Add Task Form ────────────────────────────────────────────────────────────

function showAddTaskForm(stageId) {
  document.getElementById(`addForm-${stageId}`).classList.add('visible');
  document.getElementById(`addTrigger-${stageId}`).style.display = 'none';
  document.getElementById(`addInput-${stageId}`).focus();
}

function hideAddTaskForm(stageId) {
  document.getElementById(`addForm-${stageId}`).classList.remove('visible');
  document.getElementById(`addTrigger-${stageId}`).style.display = '';
  document.getElementById(`addInput-${stageId}`).value = '';
}

async function submitAddTask(stageId) {
  const input = document.getElementById(`addInput-${stageId}`);
  const title = input.value.trim();

  if (!title) {
    input.focus();
    return;
  }

  const saveBtn = document.querySelector(`#addForm-${stageId} .add-task-save`);
  saveBtn.disabled = true;
  saveBtn.textContent = '…';

  try {
    const task = await createTask(stageId, title);

    // Inject new task into the DOM without full re-render
    const taskList = document.getElementById(`tasks-${stageId}`);
    const noTasks  = taskList.querySelector('.no-tasks');
    if (noTasks) noTasks.remove();

    const div = document.createElement('div');
    div.innerHTML = renderTaskItems([task]);
    taskList.appendChild(div.firstElementChild);

    // Update stage task counter
    updateStageCounter(stageId);

    hideAddTaskForm(stageId);
    await refreshProgress();
    showToast('Task added', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = 'Add';
  }
}

// ─── Keyboard: Enter = submit, Escape = cancel ────────────────────────────────

document.addEventListener('keydown', (e) => {
  const input = e.target;
  if (!input.classList.contains('add-task-input')) return;

  const stageId = input.id.replace('addInput-', '');

  if (e.key === 'Enter') {
    e.preventDefault();
    submitAddTask(stageId);
  } else if (e.key === 'Escape') {
    hideAddTaskForm(stageId);
  }
});

// ─── Progress Refresh ─────────────────────────────────────────────────────────

/**
 * Re-fetches the project and updates the progress bar + stage counters
 * without tearing down and rebuilding the entire stage DOM.
 */
async function refreshProgress() {
  try {
    const project = await apiFetch(`${API}/projects/${PROJECT_ID}`);
    currentProject = project;

    const progress  = project.progress ?? 0;
    const fillClass = progress >= 100 ? 'complete' : '';

    const progressFill    = document.getElementById('progressFill');
    const progressPercent = document.getElementById('progressPercent');

    if (progressFill) {
      progressFill.style.width  = `${progress}%`;
      progressFill.className    = `progress-hero-fill ${fillClass}`;
    }
    if (progressPercent) {
      progressPercent.textContent = `${progress}%`;
    }

    // Update header task count
    const metaEl = document.querySelector('.project-detail-meta .text-muted');
    if (metaEl) {
      metaEl.textContent = `${project.completedTasks}/${project.totalTasks} tasks completed`;
    }

    // Update per-stage counters
    if (project.stages) {
      project.stages.forEach(stage => updateStageCounterFromData(stage));
    }
  } catch (_) {
    // Silent fail — UI already reflects the optimistic update
  }
}

function updateStageCounter(stageId) {
  const panel      = document.getElementById(`stage-${stageId}`);
  if (!panel) return;
  const taskItems  = panel.querySelectorAll('.task-item');
  const doneItems  = panel.querySelectorAll('.task-item.completed');
  const counterEl  = panel.querySelector('.stage-task-count');
  if (counterEl) {
    counterEl.textContent = `${doneItems.length}/${taskItems.length} done`;
  }
}

function updateStageCounterFromData(stage) {
  const panel     = document.getElementById(`stage-${stage.id}`);
  if (!panel) return;
  const counterEl = panel.querySelector('.stage-task-count');
  if (!counterEl) return;
  const total    = stage.tasks ? stage.tasks.length : 0;
  const done     = stage.tasks ? stage.tasks.filter(t => t.completed).length : 0;
  counterEl.textContent = `${done}/${total} done`;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function apiFetch(url, options = {}) {
  const res = await fetch(url, options);

  if (res.status === 204) return null;

  const data = await res.json().catch(() => null);

  if (!res.ok) {
    const msg = data?.message || `Request failed: ${res.status}`;
    throw new Error(msg);
  }

  return data;
}

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className   = `toast ${type} show`;
  setTimeout(() => { toast.className = 'toast'; }, 3000);
}

function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Expose functions called from inline onclick attributes
window.handleCompleteTask  = handleCompleteTask;
window.handleDeleteTask    = handleDeleteTask;
window.showAddTaskForm     = showAddTaskForm;
window.hideAddTaskForm     = hideAddTaskForm;
window.submitAddTask       = submitAddTask;
