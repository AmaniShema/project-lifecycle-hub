/**
 * dashboard.js — Project Life-Cycle Hub
 * Manages the dashboard view: listing, creating, and deleting projects.
 *
 * All API calls go through /api/* — Nginx proxies to the Spring Boot backend.
 */

const API = '/api';

// ─── Initialization ──────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  loadProjects();
  bindModalEvents();
});

// ─── API Calls ───────────────────────────────────────────────────────────────

async function loadProjects() {
  const container = document.getElementById('projectsContainer');
  try {
    const projects = await apiFetch(`${API}/projects`);
    renderProjects(projects);
  } catch (err) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">⚠️</div>
        <h3>Could not load projects</h3>
        <p>${err.message}</p>
        <button class="btn btn-primary" onclick="loadProjects()">Retry</button>
      </div>`;
  }
}

async function createProject(name, description) {
  return apiFetch(`${API}/projects`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description }),
  });
}

async function deleteProject(id) {
  return apiFetch(`${API}/projects/${id}`, { method: 'DELETE' });
}

// ─── Rendering ───────────────────────────────────────────────────────────────

function renderProjects(projects) {
  const container = document.getElementById('projectsContainer');
  const countEl    = document.getElementById('projectCount');

  if (!projects || projects.length === 0) {
    countEl.textContent = 'No projects yet — create one to get started.';
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">📋</div>
        <h3>Your workspace is empty</h3>
        <p>Create your first project to start tracking your progress.</p>
        <button class="btn btn-primary" onclick="openCreateModal()">+ New Project</button>
      </div>`;
    return;
  }

  const total    = projects.length;
  const active   = projects.filter(p => p.progress > 0 && p.progress < 100).length;
  countEl.textContent = `${total} project${total !== 1 ? 's' : ''} · ${active} in progress`;

  container.innerHTML = `
    <div class="projects-grid">
      ${projects.map(renderProjectCard).join('')}
    </div>`;

  // Attach card click handlers (card body → navigate; delete btn → delete)
  document.querySelectorAll('.project-card[data-id]').forEach(card => {
    const id = card.dataset.id;
    card.addEventListener('click', (e) => {
      // Don't navigate if the delete button was clicked
      if (e.target.closest('.delete-btn')) return;
      window.location.href = `project.html?id=${id}`;
    });
  });

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id   = btn.dataset.id;
      const name = btn.dataset.name;
      if (!confirm(`Delete "${name}"? This will remove all stages and tasks.`)) return;
      try {
        await deleteProject(id);
        showToast('Project deleted', 'success');
        loadProjects();
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  });
}

function renderProjectCard(project) {
  const progress   = project.progress ?? 0;
  const fillClass  = progress >= 100 ? 'complete' : '';
  const stageCls   = `stage-${project.currentStage}`;

  const tasksText = project.totalTasks === 0
    ? 'No tasks yet'
    : `${project.completedTasks}/${project.totalTasks} tasks done`;

  const desc = project.description
    ? `<p class="project-description">${escapeHtml(project.description)}</p>`
    : '';

  return `
    <div class="project-card" data-id="${project.id}" role="button" tabindex="0" aria-label="Open ${escapeHtml(project.name)}">
      <div class="project-card-header">
        <span class="project-name">${escapeHtml(project.name)}</span>
        <button
          class="delete-btn"
          data-id="${project.id}"
          data-name="${escapeHtml(project.name)}"
          title="Delete project"
          aria-label="Delete ${escapeHtml(project.name)}"
        >🗑</button>
      </div>

      ${desc}

      <div class="project-meta">
        <div style="display:flex; align-items:center; gap:10px;">
          <span class="stage-badge ${stageCls}">${project.currentStage}</span>
          <span class="stats-row">
            <span>${tasksText}</span>
          </span>
        </div>

        <div class="progress-wrap">
          <div class="progress-label">
            <span>Progress</span>
            <strong>${progress}%</strong>
          </div>
          <div class="progress-bar">
            <div class="progress-fill ${fillClass}" style="width: ${progress}%"></div>
          </div>
        </div>
      </div>
    </div>`;
}

// ─── Modal ───────────────────────────────────────────────────────────────────

function bindModalEvents() {
  document.getElementById('openCreateModal').addEventListener('click', openCreateModal);
  document.getElementById('closeCreateModal').addEventListener('click', closeCreateModal);
  document.getElementById('cancelCreate').addEventListener('click', closeCreateModal);
  document.getElementById('confirmCreate').addEventListener('click', handleCreate);

  // Close on overlay click
  document.getElementById('createModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeCreateModal();
  });

  // Enter key submits form
  document.getElementById('projectName').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleCreate();
  });
}

function openCreateModal() {
  document.getElementById('createModal').classList.add('active');
  document.getElementById('projectName').focus();
}

function closeCreateModal() {
  document.getElementById('createModal').classList.remove('active');
  document.getElementById('projectName').value = '';
  document.getElementById('projectDesc').value = '';
  document.getElementById('projectNameError').style.display = 'none';
}

async function handleCreate() {
  const nameInput = document.getElementById('projectName');
  const descInput = document.getElementById('projectDesc');
  const errorEl   = document.getElementById('projectNameError');
  const confirmBtn = document.getElementById('confirmCreate');

  const name        = nameInput.value.trim();
  const description = descInput.value.trim();

  // Client-side validation
  if (!name) {
    errorEl.textContent = 'Project name is required';
    errorEl.style.display = 'block';
    nameInput.focus();
    return;
  }
  errorEl.style.display = 'none';

  // Disable button while loading
  confirmBtn.disabled = true;
  confirmBtn.textContent = 'Creating…';

  try {
    await createProject(name, description || null);
    closeCreateModal();
    showToast(`"${name}" created with 6 life-cycle stages 🚀`, 'success');
    loadProjects();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    confirmBtn.disabled = false;
    confirmBtn.textContent = 'Create Project';
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function apiFetch(url, options = {}) {
  const res = await fetch(url, options);

  if (res.status === 204) return null; // No Content

  const data = await res.json().catch(() => null);

  if (!res.ok) {
    const msg = data?.message || `Request failed: ${res.status}`;
    throw new Error(msg);
  }

  return data;
}

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `toast ${type} show`;
  setTimeout(() => { toast.className = 'toast'; }, 3500);
}

function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Expose for inline onclick in empty state
window.openCreateModal = openCreateModal;
