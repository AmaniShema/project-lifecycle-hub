package com.amani.projecthub.controller;

import com.amani.projecthub.dto.TaskCreateRequest;
import com.amani.projecthub.dto.TaskDTO;
import com.amani.projecthub.service.TaskService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for Task resources.
 *
 * Endpoints:
 *   POST   /api/tasks                  → create a task inside a stage
 *   PATCH  /api/tasks/{id}/complete    → mark task as completed
 *   DELETE /api/tasks/{id}             → delete a task
 */
@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping
    public ResponseEntity<TaskDTO> createTask(@Valid @RequestBody TaskCreateRequest request) {
        TaskDTO created = taskService.createTask(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PatchMapping("/{id}/complete")
    public ResponseEntity<TaskDTO> completeTask(@PathVariable Long id) {
        return ResponseEntity.ok(taskService.markCompleted(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
        return ResponseEntity.noContent().build();
    }
}
