package com.amani.projecthub.dto;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO for Project API responses.
 *
 * Key field: progress — this is NEVER stored in the database.
 * It is calculated dynamically by ProjectService:
 *   progress = (completedTasks / totalTasks) * 100
 *
 * stages is populated only on GET /api/projects/{id} (detail view).
 * On GET /api/projects (list view) stages is null to keep responses lean.
 */
public class ProjectDTO {

    private Long id;
    private String name;
    private String description;
    private String currentStage;
    private LocalDateTime createdAt;
    private double progress;
    private int totalTasks;
    private int completedTasks;
    private List<StageDTO> stages;

    public ProjectDTO() {}

    // ─── Getters & Setters ────────────────────────────────────────────────────

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCurrentStage() { return currentStage; }
    public void setCurrentStage(String currentStage) { this.currentStage = currentStage; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public double getProgress() { return progress; }
    public void setProgress(double progress) { this.progress = progress; }

    public int getTotalTasks() { return totalTasks; }
    public void setTotalTasks(int totalTasks) { this.totalTasks = totalTasks; }

    public int getCompletedTasks() { return completedTasks; }
    public void setCompletedTasks(int completedTasks) { this.completedTasks = completedTasks; }

    public List<StageDTO> getStages() { return stages; }
    public void setStages(List<StageDTO> stages) { this.stages = stages; }
}
