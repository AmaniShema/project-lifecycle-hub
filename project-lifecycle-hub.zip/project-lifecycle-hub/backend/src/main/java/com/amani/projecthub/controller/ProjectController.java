package com.amani.projecthub.controller;

import com.amani.projecthub.dto.ProjectCreateRequest;
import com.amani.projecthub.dto.ProjectDTO;
import com.amani.projecthub.service.ProjectService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST controller for Project resources.
 *
 * Architecture rule: controllers are intentionally thin.
 * Zero business logic lives here — only HTTP wiring.
 *
 * Endpoints:
 *   POST   /api/projects                        → create project (+ auto-creates 6 stages)
 *   GET    /api/projects                        → list all projects (summary, with progress)
 *   GET    /api/projects/{id}                   → get project detail (stages + tasks + progress)
 *   PATCH  /api/projects/{id}/stage             → update current stage
 *   DELETE /api/projects/{id}                   → delete project (cascades to stages + tasks)
 */
@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    private final ProjectService projectService;

    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

    @PostMapping
    public ResponseEntity<ProjectDTO> createProject(
            @Valid @RequestBody ProjectCreateRequest request) {
        ProjectDTO created = projectService.createProject(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<ProjectDTO>> getAllProjects() {
        return ResponseEntity.ok(projectService.getAllProjects());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProjectDTO> getProjectById(@PathVariable Long id) {
        return ResponseEntity.ok(projectService.getProjectById(id));
    }

    @PatchMapping("/{id}/stage")
    public ResponseEntity<ProjectDTO> updateStage(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        String stage = body.get("stage");
        return ResponseEntity.ok(projectService.updateCurrentStage(id, stage));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProject(@PathVariable Long id) {
        projectService.deleteProject(id);
        return ResponseEntity.noContent().build();
    }
}
