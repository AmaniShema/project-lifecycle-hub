package com.amani.projecthub.repository;

import com.amani.projecthub.model.Stage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StageRepository extends JpaRepository<Stage, Long> {

    /**
     * Returns all stages for a project in the canonical lifecycle order.
     * orderIndex 0 = IDEA → 5 = MAINTENANCE
     */
    List<Stage> findByProjectIdOrderByOrderIndex(Long projectId);
}
