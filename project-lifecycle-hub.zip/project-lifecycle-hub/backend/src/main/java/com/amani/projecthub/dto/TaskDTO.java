package com.amani.projecthub.dto;

import java.time.LocalDateTime;

/**
 * DTO for Task — never expose the entity directly to prevent
 * circular JSON references from the bidirectional relationships.
 */
public class TaskDTO {

    private Long id;
    private String title;
    private boolean completed;
    private LocalDateTime createdAt;

    public TaskDTO() {}

    public TaskDTO(Long id, String title, boolean completed, LocalDateTime createdAt) {
        this.id = id;
        this.title = title;
        this.completed = completed;
        this.createdAt = createdAt;
    }

    // ─── Getters & Setters ────────────────────────────────────────────────────

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
