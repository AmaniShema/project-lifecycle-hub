package com.amani.projecthub.exception;

/**
 * Thrown when a requested resource (Project, Stage, Task) does not exist.
 * Mapped to HTTP 404 by GlobalExceptionHandler.
 */
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
