package com.amani.projecthub.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Request body for POST /api/tasks.
 */
public class TaskCreateRequest {

    @NotBlank(message = "Task title is required")
    @Size(max = 500, message = "Task title must not exceed 500 characters")
    private String title;

    @NotNull(message = "stageId is required")
    private Long stageId;

    @NotNull(message = "projectId is required")
    private Long projectId;

    public TaskCreateRequest() {}

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public Long getStageId() { return stageId; }
    public void setStageId(Long stageId) { this.stageId = stageId; }

    public Long getProjectId() { return projectId; }
    public void setProjectId(Long projectId) { this.projectId = projectId; }
}
