package com.amani.projecthub.dto;

import java.util.List;

/**
 * DTO for Stage — carries its ordered task list.
 */
public class StageDTO {

    private Long id;
    private String name;
    private int orderIndex;
    private List<TaskDTO> tasks;

    public StageDTO() {}

    public StageDTO(Long id, String name, int orderIndex, List<TaskDTO> tasks) {
        this.id = id;
        this.name = name;
        this.orderIndex = orderIndex;
        this.tasks = tasks;
    }

    // ─── Getters & Setters ────────────────────────────────────────────────────

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getOrderIndex() { return orderIndex; }
    public void setOrderIndex(int orderIndex) { this.orderIndex = orderIndex; }

    public List<TaskDTO> getTasks() { return tasks; }
    public void setTasks(List<TaskDTO> tasks) { this.tasks = tasks; }
}
