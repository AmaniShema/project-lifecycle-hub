package com.amani.projecthub.service;

import com.amani.projecthub.dto.ProjectCreateRequest;
import com.amani.projecthub.dto.ProjectDTO;
import com.amani.projecthub.dto.StageDTO;
import com.amani.projecthub.dto.TaskDTO;
import com.amani.projecthub.exception.ResourceNotFoundException;
import com.amani.projecthub.model.Project;
import com.amani.projecthub.model.Stage;
import com.amani.projecthub.model.Task;
import com.amani.projecthub.repository.ProjectRepository;
import com.amani.projecthub.repository.StageRepository;
import com.amani.projecthub.repository.TaskRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Business logic for Project lifecycle management.
 *
 * Progress formula (never stored, always computed):
 *   progress = (completedTasks / totalTasks) * 100
 *   Returns 0.0 when there are no tasks (avoids division by zero).
 */
@Service
@Transactional
public class ProjectService {

    /**
     * Canonical lifecycle stage sequence.
     * Index position becomes the orderIndex stored in the Stage entity.
     */
    private static final String[] DEFAULT_STAGES = {
        "IDEA", "PLANNING", "BUILDING", "TESTING", "LAUNCH", "MAINTENANCE"
    };

    private final ProjectRepository projectRepository;
    private final StageRepository stageRepository;
    private final TaskRepository taskRepository;

    public ProjectService(ProjectRepository projectRepository,
                          StageRepository stageRepository,
                          TaskRepository taskRepository) {
        this.projectRepository = projectRepository;
        this.stageRepository = stageRepository;
        this.taskRepository = taskRepository;
    }

    // ─── Create ───────────────────────────────────────────────────────────────

    /**
     * Creates a project and auto-creates all 6 default lifecycle stages.
     */
    public ProjectDTO createProject(ProjectCreateRequest request) {
        Project project = new Project();
        project.setName(request.getName().trim());
        project.setDescription(request.getDescription() != null
                ? request.getDescription().trim() : null);
        project.setCurrentStage("IDEA");

        Project saved = projectRepository.save(project);

        for (int i = 0; i < DEFAULT_STAGES.length; i++) {
            stageRepository.save(new Stage(DEFAULT_STAGES[i], i, saved));
        }

        return toSummaryDTO(saved);
    }

    // ─── Read ─────────────────────────────────────────────────────────────────

    /**
     * Returns all projects ordered by creation date (newest first).
     * Stages are not included — this is the dashboard list view.
     */
    @Transactional(readOnly = true)
    public List<ProjectDTO> getAllProjects() {
        return projectRepository.findAllByOrderByCreatedAtDesc()
                .stream()
                .map(this::toSummaryDTO)
                .collect(Collectors.toList());
    }

    /**
     * Returns a single project with full stage + task tree.
     * Used by the project detail page.
     */
    @Transactional(readOnly = true)
    public ProjectDTO getProjectById(Long id) {
        Project project = findProjectOrThrow(id);
        return toDetailDTO(project);
    }

    // ─── Update ───────────────────────────────────────────────────────────────

    /**
     * Moves a project to a new lifecycle stage.
     */
    public ProjectDTO updateCurrentStage(Long projectId, String stage) {
        Project project = findProjectOrThrow(projectId);
        project.setCurrentStage(stage.toUpperCase());
        return toSummaryDTO(projectRepository.save(project));
    }

    // ─── Delete ───────────────────────────────────────────────────────────────

    /**
     * Deletes project and all its stages/tasks (cascade).
     */
    public void deleteProject(Long id) {
        if (!projectRepository.existsById(id)) {
            throw new ResourceNotFoundException("Project not found with id: " + id);
        }
        projectRepository.deleteById(id);
    }

    // ─── DTO Conversion ───────────────────────────────────────────────────────

    /**
     * Lightweight DTO — progress only, no stage tree.
     * Used for the dashboard list.
     */
    private ProjectDTO toSummaryDTO(Project project) {
        List<Task> tasks = taskRepository.findByProjectId(project.getId());
        return buildProjectDTO(project, null, tasks);
    }

    /**
     * Full DTO — includes stage tree with tasks.
     * Used for the project detail page.
     *
     * Efficiency: loads all tasks once, then groups by stageId in memory.
     * Avoids N+1 queries (only 2 DB calls: one for stages, one for tasks).
     */
    private ProjectDTO toDetailDTO(Project project) {
        List<Stage> stages = stageRepository
                .findByProjectIdOrderByOrderIndex(project.getId());
        List<Task> allTasks = taskRepository.findByProjectId(project.getId());

        // Group tasks by stage ID in memory — O(n) single pass
        Map<Long, List<Task>> tasksByStageId = allTasks.stream()
                .collect(Collectors.groupingBy(t -> t.getStage().getId()));

        List<StageDTO> stageDTOs = stages.stream()
                .map(stage -> {
                    List<TaskDTO> taskDTOs = tasksByStageId
                            .getOrDefault(stage.getId(), List.of())
                            .stream()
                            .map(this::toTaskDTO)
                            .collect(Collectors.toList());
                    return new StageDTO(stage.getId(), stage.getName(),
                                       stage.getOrderIndex(), taskDTOs);
                })
                .collect(Collectors.toList());

        return buildProjectDTO(project, stageDTOs, allTasks);
    }

    /**
     * Core DTO builder.
     *
     * Progress is calculated here — the ONLY place. It is never persisted.
     * Rounds to one decimal place (e.g., 66.7% not 66.666...)
     */
    private ProjectDTO buildProjectDTO(Project project,
                                       List<StageDTO> stages,
                                       List<Task> tasks) {
        int total = tasks.size();
        int completed = (int) tasks.stream().filter(Task::isCompleted).count();
        double progress = total > 0
                ? Math.round((double) completed / total * 1000.0) / 10.0
                : 0.0;

        ProjectDTO dto = new ProjectDTO();
        dto.setId(project.getId());
        dto.setName(project.getName());
        dto.setDescription(project.getDescription());
        dto.setCurrentStage(project.getCurrentStage());
        dto.setCreatedAt(project.getCreatedAt());
        dto.setProgress(progress);
        dto.setTotalTasks(total);
        dto.setCompletedTasks(completed);
        dto.setStages(stages);
        return dto;
    }

    private TaskDTO toTaskDTO(Task task) {
        return new TaskDTO(task.getId(), task.getTitle(),
                           task.isCompleted(), task.getCreatedAt());
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private Project findProjectOrThrow(Long id) {
        return projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Project not found with id: " + id));
    }
}
