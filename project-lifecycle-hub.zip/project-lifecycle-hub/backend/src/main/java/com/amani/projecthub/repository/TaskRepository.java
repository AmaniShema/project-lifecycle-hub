package com.amani.projecthub.repository;

import com.amani.projecthub.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {

    /** All tasks for a project — used for progress calculation. */
    List<Task> findByProjectId(Long projectId);

    /** All tasks for a specific stage — used when building stage detail. */
    List<Task> findByStageId(Long stageId);
}
