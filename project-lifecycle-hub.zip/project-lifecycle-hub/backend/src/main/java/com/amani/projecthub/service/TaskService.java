package com.amani.projecthub.service;

import com.amani.projecthub.dto.TaskCreateRequest;
import com.amani.projecthub.dto.TaskDTO;
import com.amani.projecthub.exception.ResourceNotFoundException;
import com.amani.projecthub.model.Project;
import com.amani.projecthub.model.Stage;
import com.amani.projecthub.model.Task;
import com.amani.projecthub.repository.ProjectRepository;
import com.amani.projecthub.repository.StageRepository;
import com.amani.projecthub.repository.TaskRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Business logic for Task management.
 *
 * Design note: tasks are validated against their parent project and stage
 * before creation — ensuring referential integrity at the service layer,
 * not just at the DB level.
 */
@Service
@Transactional
public class TaskService {

    private final TaskRepository taskRepository;
    private final ProjectRepository projectRepository;
    private final StageRepository stageRepository;

    public TaskService(TaskRepository taskRepository,
                       ProjectRepository projectRepository,
                       StageRepository stageRepository) {
        this.taskRepository = taskRepository;
        this.projectRepository = projectRepository;
        this.stageRepository = stageRepository;
    }

    /**
     * Creates a task inside a specific stage.
     * Validates that both the project and stage exist before saving.
     */
    public TaskDTO createTask(TaskCreateRequest request) {
        Project project = projectRepository.findById(request.getProjectId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Project not found with id: " + request.getProjectId()));

        Stage stage = stageRepository.findById(request.getStageId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Stage not found with id: " + request.getStageId()));

        Task task = new Task(request.getTitle().trim(), stage, project);
        Task saved = taskRepository.save(task);
        return toDTO(saved);
    }

    /**
     * Marks a task as completed.
     * Idempotent — calling multiple times on an already-complete task is safe.
     */
    public TaskDTO markCompleted(Long taskId) {
        Task task = findTaskOrThrow(taskId);
        task.setCompleted(true);
        return toDTO(taskRepository.save(task));
    }

    /**
     * Deletes a task by ID.
     */
    public void deleteTask(Long taskId) {
        if (!taskRepository.existsById(taskId)) {
            throw new ResourceNotFoundException("Task not found with id: " + taskId);
        }
        taskRepository.deleteById(taskId);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private Task findTaskOrThrow(Long id) {
        return taskRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Task not found with id: " + id));
    }

    private TaskDTO toDTO(Task task) {
        return new TaskDTO(task.getId(), task.getTitle(),
                           task.isCompleted(), task.getCreatedAt());
    }
}
